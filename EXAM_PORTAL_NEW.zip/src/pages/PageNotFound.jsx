import React from 'react'

const PageNotFound = () => {
  return (
    <div>
      404 page not found
    </div>
  )
}

export default PageNotFound
